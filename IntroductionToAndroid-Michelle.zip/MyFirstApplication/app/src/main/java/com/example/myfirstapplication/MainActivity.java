package com.example.myfirstapplication;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import com.mixpanel.android.mpmetrics.MixpanelAPI;

import org.json.JSONObject;


public class MainActivity extends AppCompatActivity {

    public static final String MIXPANEL_TOKEN = "6b0c04f93725e4767995398c0aed0e44";
    private MixpanelAPI mixpanel;
    private Context mContext;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mContext = this;
        MixpanelAPI mixpanel =
                MixpanelAPI.getInstance(mContext, MIXPANEL_TOKEN);
        mixpanel.track("App launched");

        Button mainButton = (Button) findViewById(R.id.btnMain);
        final Context activityContext = this;
        final Sticker mySticker = new Sticker(true);
        mixpanel.track("Request Sticker");

        mainButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent myIntent = new Intent(activityContext, StickerActivity.class);
                myIntent.putExtra("Sticker Id", mySticker.getSticketId());
                startActivity(myIntent);
            }
        });
        mixpanel.track("New Sticker");
    }

    @Override
    protected void onDestroy() {
        mixpanel.flush();
        super.onDestroy();
    }

}
